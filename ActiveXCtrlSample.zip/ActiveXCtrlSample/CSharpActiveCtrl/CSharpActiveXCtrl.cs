using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Microsoft.Win32;
using System.Reflection;

namespace DotNetActiveX
{

    [ComVisible(true)]
    [Guid(CSharpActiveXCtrl.EventsId)]
    [TypeLibType((short)0x1090)]
    [InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public interface ISampleControlFormCOMEvents
    {
        [DispId(1)]
        void BtnClicked();
    }

    /// <summary>
    /// COM Interface - enables to run c# code from c++
    /// </summary>
    [InterfaceType(ComInterfaceType.InterfaceIsDual)]
    public interface ICSharpActiveXCtrl
    {
        [DispId(2)]
        void DestroyComponent();
    }

    [ComVisible(true)]
    [Guid(CSharpActiveXCtrl.ClassId)]
    [ProgId("DotNetActiveX.CSharpActiveXCtrl")]
    [ClassInterface(ClassInterfaceType.None)]
    [TypeLibType((short)0x24)]   
    [DefaultEvent("BtnClicked")]
    [ComSourceInterfaces(typeof(ISampleControlFormCOMEvents))]
    public partial class CSharpActiveXCtrl : UserControl, ICSharpActiveXCtrl
    {
        public const string EventsId = "AAF1BC99-12A6-4207-8E70-7C46DDF590FE";

        /// <summary>Class GUID</summary>

        public const string ClassId = "9DC83897-CE0F-480F-9DD8-7830882E7E72";

        /// <summary>Interface GUID</summary>
        public const string InterfaceId = "3B10ED06-4CF9-4E92-9ECA-A4C5C3A42EE5";
        
        public new event BtnClickedEventHandler BtnClicked;
        public delegate void BtnClickedEventHandler();

        public CSharpActiveXCtrl()
        {
            InitializeComponent();
            string srchString = "https://my.cerner.com/Pages/default.aspx";
            webBrowser1.Navigate(srchString);

        }

        /// <summary>
        /// Set new caption for Button OK
        /// </summary>
        /// <param name="strNewCaption">New Caption String</param>
        public void setButtonCaption(String strNewCaption)
        {
            btnOK.Text = strNewCaption;
        }
        
        /// <summary>
        /// Regsiter ActiveX dll function
        /// </summary>
        /// <param name="i_Key">registration key</param>
        [ComRegisterFunction()]
        public static void RegisterClass(string i_Key)
        {
            // strip off HKEY_CLASSES_ROOT\ from the passed key as I don't need it
            StringBuilder sb = new StringBuilder(i_Key);
            sb.Replace(@"HKEY_CLASSES_ROOT\", "");

            // open the CLSID\{guid} key for write access
            RegistryKey registerKey = Registry.ClassesRoot.OpenSubKey(sb.ToString(), true);

            // and create the 'Control' key - this allows it to show up in 
            // the ActiveX control container 
            RegistryKey ctrl = registerKey.CreateSubKey("Control");
            ctrl.Close();

            // next create the CodeBase entry - needed if not string named and GACced.
            RegistryKey inprocServer32 = registerKey.OpenSubKey("InprocServer32", true);
            inprocServer32.SetValue("CodeBase", Assembly.GetExecutingAssembly().CodeBase);
            inprocServer32.Close();

            // finally close the main key
            registerKey.Close();
        }

        /// <summary>
        /// Unregister ActiveX dll function
        /// </summary>
        /// <param name="i_Key"></param>
        [ComUnregisterFunction()]
        public static void UnregisterClass(string i_Key)
        {
            // strip off HKEY_CLASSES_ROOT\ from the passed key as I don't need it
            StringBuilder sb = new StringBuilder(i_Key);
            sb.Replace(@"HKEY_CLASSES_ROOT\", "");

            // open HKCR\CLSID\{guid} for write access
            RegistryKey registerKey = Registry.ClassesRoot.OpenSubKey(sb.ToString(), true);

            // delete the 'Control' key, but don't throw an exception if it does not exist
            registerKey.DeleteSubKey("Control", false);

            // next open up InprocServer32
            RegistryKey inprocServer32 = registerKey.OpenSubKey("InprocServer32", true);

            // and delete the CodeBase key, again not throwing if missing
            inprocServer32.DeleteSubKey("CodeBase", false);

            // finally close the main key
            registerKey.Close();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            BtnClicked();
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            BtnClicked();
        }

        public void DestroyComponent()
        {
            if(BtnClicked != null && BtnClicked.Target != null)
            {
                if (Marshal.IsComObject(BtnClicked.Target))
                {
                    Marshal.FinalReleaseComObject(BtnClicked.Target);
                }
            }
        }
    }
}