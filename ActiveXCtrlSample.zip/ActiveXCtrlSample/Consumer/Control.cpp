// CCernerTextEditorCOM.cpp  : Definition of ActiveX Control wrapper class(es) created by Microsoft Visual C++


#include "stdafx.h"
#include "Control.h"

/////////////////////////////////////////////////////////////////////////////
// CCernerTextEditorCOM

 IMPLEMENT_DYNCREATE(CCustomControl, CWnd)


 // CCernerTextEditorCOM properties

 // CCernerTextEditorCOM operations