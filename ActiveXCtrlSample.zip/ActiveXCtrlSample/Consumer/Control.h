
#pragma once
     
class CCustomControl : public CWnd
{
protected:
	DECLARE_DYNCREATE(CCustomControl)
public:
	CLSID const& GetClsid()
	{
		static CLSID const clsid			
			= { 0x9dc83897, 0xce0f, 0x480f,{ 0x9d, 0xd8, 0x78, 0x30, 0x88, 0x2e, 0x7e, 0x72 } };
		return clsid;
	}
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle,
		const RECT& rect, CWnd* pParentWnd, UINT nID,
		CCreateContext* pContext = NULL)
	{
		return CreateControl(GetClsid(), lpszWindowName, dwStyle, rect, pParentWnd, nID);
	}

	BOOL Create(LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd,
		UINT nID, CFile* pPersist = NULL, BOOL bStorage = FALSE,
		BSTR bstrLicKey = NULL)
	{
		return CreateControl(GetClsid(), lpszWindowName, dwStyle, rect, pParentWnd, nID,
			pPersist, bStorage, bstrLicKey);
	}

	
public:
	void DestroyComponent()
	{
		InvokeHelper(0x2, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
	}

};